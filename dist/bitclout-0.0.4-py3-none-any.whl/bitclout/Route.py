
ROUTE = "https://bitclout.com/api/v0/"
def getRoute():
    return ROUTE

def setRoute(route):
     #you can route the APIs to other nodes ex. https://love4src.com/api/v0/ etc.
    ROUTE = route
